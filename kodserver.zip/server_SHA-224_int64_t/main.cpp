#include <iostream>
#include "connection.cpp"
//#include "interface.h"
#include "errno.h"
#include <system_error>
#include <netinet/in.h>
#include <memory>
#include <arpa/inet.h>
#include <sys/socket.h>
#include <string>


int main(int argc, const char** argv)
{
    Interface interface;
        if(!interface.Parser(argc, argv)){
            cout << interface.getDescription() << endl;
            return 1;
        }
    Params params = interface.getParams();
    conn(&params);//&params
    return 0;
}